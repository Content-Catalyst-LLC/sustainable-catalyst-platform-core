# Sustainable Catalyst Public API JavaScript Client v2.37.0.2

```javascript
import { PublicApiClient } from "./index.mjs";

const client = new PublicApiClient(
  "https://YOUR-PLATFORM-CORE.onrender.com",
  "scpk_your_key"
);

console.log(await client.status());
console.log(await client.trustStatus());
console.log(await client.workflowDefinitions());
console.log(await client.dossiers());
console.log(await client.verifyDossier("sc:dossier:..."));
```

## Live data gateway v2.7.0

```js
const sources = await client.liveSources();
const connectors = await client.liveConnectors({ domain: "hazards" });
const events = await client.liveObservations({ connector_id: "usgs.earthquakes" });
const series = await client.liveTimeseries("SP.POP.TOTL", { source_id: "world-bank" });
const lineage = await client.liveProvenance(events[0].id);
```

These methods require the `data:read` scope.


## International law and UN records v2.7.1

Use the international-law record, detail, and authority-taxonomy client methods to consume official-source records without exposing connector configuration or raw payloads.

## Scientific data v2.7.2

Use `scientific_records`, `scientific_record`, and `scientific_record_types` (camelCase in JavaScript) to discover normalized public scientific records through the scoped API.


## Economics and official statistics v2.7.3

```javascript
const records = await client.economicRecords({ indicator_code: "GDP", geography_code: "USA", limit: 25 });
const record = await client.economicRecord(records[0].id);
const types = await client.economicRecordTypes();
```


## Data fabric v2.8.1

```javascript
const capabilities = await client.fabricCapabilities();
const features = await client.geospatialFeatures({ bbox: "-88,41,-87,42" });
const series = await client.timeSeries({ metric: "temperature" });
const points = await client.timeSeriesPoints(series[0].id);
const assets = await client.scientificAssets({ format: "fits" });
const layers = await client.mapLayers({ layer_type: "cog" });
const stac = await client.stacSearch({ collections: "mast:JWST" });
```


## Streaming v2.13.0

The public client exposes a reliability stream URL helper for the Server-Sent Events endpoint. SSE consumers must send the normal scoped Bearer credential. Public streams contain only events explicitly marked public.

## Operational facilities v2.13.0

List public facilities by country/type/bbox, retrieve a public facility, and inspect dated facility observations. Operational, damage, access, service, capacity, and supply dimensions remain distinct.


## Humanitarian access and essential services v2.13.0

Query public humanitarian-condition records and country summaries while preserving service domain, evidence role, facility linkage, source, period, and provenance. Structural baselines are not presented as current operational conditions.

## Country evidence federation v2.13.0

Use `countryEvidenceFederation(countryCode)` and `countryEvidenceReconcile(countryCode, concept)` to inspect federated country evidence and reconciliation decisions without automatic averaging.


## Earth, Ocean, Space scientific fabric v2.13.0
Discover routed scientific domains and retrieve domain-specific records, assets, time series, and map layers. Domain routing is navigation metadata only and has no factual Truth precedence.


## Cross-product evidence exchange v2.14.0

The public SDK exposes exchange readiness/capability metadata only. Exchange package contents remain an authenticated internal Core surface.


## Distributed scale v2.15.0
Use `/api/v1/scale/readiness` for public-safe capacity and backpressure state. Processing job payloads remain operator-only.


## Governance v2.16.0
Use `governance_readiness` / `governanceReadiness()` to inspect the public-safe governance control-plane status. Policy, decision, and audit data are intentionally not exposed through the public API.

## Production certification v2.17.0
Public-safe certification readiness reports migration head, zero-pending state, and recovery-checkpoint capability without exposing certification records.


## Observability v2.18.0
Public-safe aggregate production status is available through the observability status helper. Request IDs, raw request telemetry, SLO definitions, and operator deployment metadata are not exposed by this helper.


## Federated Core v2.23.0
Use `federation_status()` / `federationStatus()` for aggregate public-safe trusted-node exchange readiness. Node identities, trust details, manifests, signatures, and remote-reference contents are not exposed through this helper.

## v2.24.0
Adds `capacityStatus()` for aggregate Capacity Forecasting & Resource Governance status.

## v2.25.0

Adds `credentialLifecycleStatus()` for public-safe aggregate credential/key lifecycle health. Secret references, key identifiers, fingerprints, and secret/private-key material are not returned by the public status contract.


## v2.27.0 — Scientific object metadata

Use `scientificObjectStorageReadiness()`, `scientificStoredObjects(...)`, `scientificStoredObject(id)`, and `scientificProcessingAdapters()` for public-safe storage and adapter metadata. Raw object bytes and execution remain internal.


## v2.28.0 — Research objects

The client exposes `researchObjectReadiness()`, `researchObjects()`, `researchObject()`, and `researchProjectBundle()` for public, graph-native research metadata. Model execution remains in Lab, Workbench, or an explicitly external executor.


## v2.29.0 — Visual reasoning

The public client exposes renderer-neutral visual reasoning readiness, public visual-object listing/detail, and semantic bundles. Core returns semantic elements, relations, layers, annotations, and snapshot metadata; it does not return a renderer choice or execute layout.


## v2.30.0 — Visualization specification & renderer registry

Use `visualizationReadiness()`, `visualizationRenderers()`, and `visualizationSpecifications()` to inspect public-safe renderer contracts and governed visualization specifications. Core resolves compatibility metadata only; it does not execute renderers or layouts.


## v2.31.0 — System Maps
Adds `systemMapsReadiness`, `systemMaps`, `systemMap`, and `systemMapBundle`.


## v2.33.0 — Flow Maps
Adds public Flow Maps readiness, listing, detail, bundle, and unit-safe balance-summary helpers. Core does not convert units or execute simulations.


## v2.33.0 — Scenario Landscapes

Adds `scenarioLandscapesReadiness`, `scenarioLandscapes`, `scenarioLandscape`, `scenarioLandscapeBundle`, and `scenarioLandscapeComparison`. Core persists comparison semantics; compute, ranking, and optimization remain external.


## v2.35.0 — Scenario Compute Engine
Adds public readiness/list/detail/bundle helpers for governed interactive model canvases. Model execution remains external to Core.


## v2.36.0 — Uncertainty, Sensitivity & Ensemble Reasoning
Adds public metadata helpers for governed uncertainty definitions, sensitivity-study summaries, and ensemble summaries. Sampling, model execution, sensitivity algorithms, and ensemble aggregation remain external to Platform Core.


## v2.37.0.2 — Uncertainty Compute Runtime Integration repair
Adds public compute readiness helpers while preserving v2.36.0 uncertainty APIs.

## v2.37.0.2 — Causal Systems Explorer
Public readiness, graph discovery, and public causal-system bundle helpers.

## v2.37.0.2 — Causal Migration Metadata Repair

Runtime/API surface unchanged from v2.37.0; release metadata and promotion/deployment integrity repaired.
